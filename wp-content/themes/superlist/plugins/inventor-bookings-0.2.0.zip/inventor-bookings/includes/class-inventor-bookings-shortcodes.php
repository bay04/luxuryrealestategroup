<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Inventor_Bookings_Shortcodes
 *
 * @class Inventor_Bookings_Shortcodes
 * @package Inventor/Classes
 * @author Pragmatic Mates
 */
class Inventor_Bookings_Shortcodes {
    /**
     * Initialize shortcodes
     *
     * @access public
     * @return void
     */
    public static function init() {
        add_shortcode( 'inventor_booking_detail', array( __CLASS__, 'booking_detail' ) );
    }

    /**
     * Booking detail
     *
     * @param $atts
     * @param $atts|array
     * @return string
     */
    public static function booking_detail( $atts = array() ) {
        $hash = ! empty( $_GET['hash'] ) ? esc_attr( $_GET['hash'] ) : null;
        $booking = Inventor_Bookings_Logic::get_booking_by_hash( $hash );
        $booking_status = get_post_meta( $booking->ID, INVENTOR_BOOKING_PREFIX . 'status', true );

        if ( $booking_status == 'pending_payment' && ! is_user_logged_in() ) {
            return Inventor_Template_Loader::load( 'misc/not-allowed' );
        }

        $args = array();

        if ( ! empty( $booking ) ) {
            $args = array(
                'booking'         => $booking,
                'listing'         => Inventor_Bookings_Logic::get_booking_listing( $booking->ID ),
            );
        }

        return Inventor_Template_Loader::load( 'bookings/detail', $args, INVENTOR_BOOKINGS_DIR );
    }
}

Inventor_Bookings_Shortcodes::init();
