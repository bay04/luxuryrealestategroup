<?php $pros_and_cons_enabled = get_theme_mod( 'inventor_reviews_pros_and_cons_enabled', true ); ?>
<?php $class = $pros_and_cons_enabled ? 'review-form-comment' : 'review-form-review'; ?>

<div class="form-group <?php echo $class; ?>">
    <label><?php echo __( 'Review', 'inventor-reviews' ); ?></label>

    <?php $default_message = $pros_and_cons_enabled ? 'REVIEW on ' . get_the_title() . ' on ' . current_time( 'mysql' ) : ''; ?>

    <textarea id="comment"
              name="comment"
              rows="4"
              required="required"><?php echo $default_message; ?></textarea>
</div><!-- /.form-group -->